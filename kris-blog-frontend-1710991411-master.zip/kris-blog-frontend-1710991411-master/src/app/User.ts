export class User
{
fullName:string;
userName:string;
email:string;
password:string;
active:string;
role:string
constructor(fullName:string,userName:string,email:string,password:string,active:string,role:string){
this.fullName=fullName;
this.userName=userName;
this.email=email;
this.password=password;
this.active=active;
this.role=role;
}
}
